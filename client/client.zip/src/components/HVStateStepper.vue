<template>
  <div class="hv-state-stepper">
    <v-stepper alt-labels class="hidden-xs-only">
      <v-stepper-header>
        <template v-for="(state, stateIndex) in states">
          <v-menu :key="stateIndex" bottom offset-y open-on-hover>
            <template #activator="{ on, value }">
              <v-stepper-step
                @mouseenter.native="on.mouseenter"
                @mouseleave.native="on.mouseleave"
                :class="[value && 'v-stepper__step--hover']"
                :color="state.current ? currentColor : previousColor"
                :complete="stateIndex <= currentIndex"
                :complete-icon="state.current ? currentIcon : previousIcon"
                step=""
              >
                {{ state.name }}
              </v-stepper-step>
            </template>
            <v-card>
              <v-card-title class="font-weight-bold subtitle-1" v-if="$vuetify.breakpoint.smOnly">{{ state.name }}</v-card-title>
            </v-card>
          </v-menu>
          <v-divider :key="`d${stateIndex}`" v-if="stateIndex < states.length - 1" />
        </template>
      </v-stepper-header>
    </v-stepper>
  </div>
</template>

<script>

export default {
  computed: {
    currentIndex() {
      return this.states.findIndex(state => state.current);
    },
  },
  name: 'HVStateStepper',
  props: {
    currentColor: String,
    currentIcon: String,
    previousColor: String,
    previousIcon: String,
    states: {
      type: Array,
      required: true
    },
  },
};
</script>

<style scoped>
.hv-state-stepper .v-stepper__header .v-stepper__step {
  flex-basis: 100px !important;
  padding: 8px 0 !important;
}
.hv-state-stepper .v-stepper__header .v-stepper__step__step {
  border-style: groove;
  border-width: 0;
  transition: border-width .3s;
}
.hv-state-stepper .v-stepper__header .v-stepper__step--hover .v-stepper__step__step {
  border-width: 12px;
}
.hv-state-stepper .v-stepper__header .v-stepper__label {
  text-align: center;
}
.hv-state-stepper .v-stepper__header .v-divider {
  margin: 20px -34px 0;
}
</style>